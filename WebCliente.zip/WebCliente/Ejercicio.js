// FunciÃ³n que calcula la media de los elementos de un array


function average(numbers) {
    var sum = 0;
    numbers.forEach(myFunction);

    function myFunction(item) {
        sum += item;
    }
    return sum/numbers.length;
}

function averageArrow(numbers) {
    var sum = 0;
    numbers.forEach((x) => {
        sum+=x;
});
    return sum/numbers.length;
}


console.log(average([65, 44, 12, 4]));
console.log(averageArrow([65, 44, 12, 4]));

// Obtener el mayor de los elementos de un array

//Funcion comparadora por elementos pares.
function cmp(a,b) {

    return a-b;
}
function greatest(numbers) {
    sorted =  numbers.sort(cmp);
    return sorted[sorted.length - 1];
}

console.log(greatest([3,11,0,57,1,2]));

// Obtener el menor de los elementos de un array

function smallest(numbers) {
    sorted =  numbers.sort(cmp);
    return sorted[0];
}

console.log(smallest([3,11,0,57,1,2]));

// Sort custom // Primero pares, de mayor a menor, luego impares, de menor a mayor

var points = [40, 100, 1, 5, 25, 10];
points.sort(function(a, b){
    if (a % 2 === 0 && b % 2 !== 0) {
        return -1;
    } else if (a % 2 !== 0 && b % 2 === 0) {
        return 1;
    } else {
        if (a % 2 === 0) {
            return b - a;
        } else {
            return a - b;
        }
    }
});

console.log(points);

// Lo mismo pero con una función arrow

console.log([40, 100, 1, 5, 25, 10].sort((a, b) => {
        if (a % 2 === 0 && b % 2 !== 0) {
    return -1;
} else if (a % 2 !== 0 && b % 2 === 0) {
    return 1;
} else if (a % 2 === 0) {
    return b - a;
} else {
    return a - b;
}
}));

j = '{\n' +
    '  "userId": 1,\n' +
    '  "id": 1,\n' +
    '  "title": "delectus aut autem",\n' +
    '  "completed": false\n' +
    '}';

p = JSON.parse(j);
console.log(p);
console.log(p);


console.log([1,2,3,4,5].map(function (pow(n)) {
    return n**2;
}));




// Función que coja un string y genere un string palíndromo a partir de él de la forma: "hola" -> "holaloh"
//s sera nuestro string

function makePalindromo(s) {
    //Dentro del split le metemos las comillas simples, esto hara que el string reciba "hachazos"
    //El reverse le dara la vuelta al string y slice nos limitara el inicio y final del string.
    //La funcion join, recibe comillas simples para poder juntarlos bien y no dejar una separacion entre ellos

    return s+ s.split('').reverse().slice(1, s.length).join('');
}
console.log(makePalindromo("hola"))
// Función que da la vuelta a un número 1234 -> 4321, 1000 -> 1
//n sera nuestro numero y tengo que convertirlo en un string para poder hacer estas operaciones.
//Usamos la funcion parseint para poder convertir de string a numero nuestro numero para poder asi realizar las operaciones necesarias
//que son muy similares a las anteriores.
function invertir(n) {
    return  parseInt(.toString().slipt('').reverse().join(''));
    }
// Función que determine si un número es "perfecto"
// Un número es perfecto cuando es igual a la suma de sus divisores (sin contarse a él mismo). Por ejemplo: 6 = 1 + 2 + 3

function esPerfecto(n){
    var total=0;

    for(i=1;i<=n/2;i++)
    {
        if(n%i===0)
            total+=1;
    }
    return total==n;
}

// Función que devuelve el mayor palíndromo incluído en un string: "banana" -> "anana"


// Implementar el algoritmo de ordenación de "la burbuja"
// Se recorre la lista comparando pares, y los invierte si no estén ordenados. Igual que con el sort de JS,
// podremos pasarle la función comparadora

function(burbuja(array,fnc))
{
    for(var i=0; i<array.length-1;i++)
    {
        for(var j=0;j<array.length-i-1;i++)
        {
            if(fnc(array[j],array[j+1])>0)
            {
                var temp=array[j];
                array[j]=array[j+1];
                array[j+1]=temp;

            }
        }
    }
}

console.log(burbuja([1,2,3,4,6,5,10,11,9,8,7],cmp))