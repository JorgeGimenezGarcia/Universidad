function Persona(nombre,apellidos,edad) {
  this.nombre=nombre;
  this.apellidos=apellidos;
  this.edad=edad;
}

var data_source=[
  new Persona("Juan","Gonzalez",25),
  new Persona("Luisa","Gomez",46),
  new Persona("Alvaro","Puente",20)
];

function create_table() {
  var body=document.getElementsByTagName('body')[0];//[0] porque solo hay un body
  var tbl=document.createElement('table');
  tbl.setAttribute('border',1);//para poner bordes

  body.appendChild(tbl);
  var rowHeaders=document.createElement('tr');
  tbl.appendChild(rowHeaders);

  var headerNombre=document.createElement('th');
  var headerApellidos=document.createElement('th');
  var headerEdad=document.createElement('th');

  rowHeaders.appendChild(headerNombre);
  rowHeaders.appendChild(headerApellidos);
  rowHeaders.appendChild(headerEdad);

  headerNombre.innerHTML='Nombre';
  headerApellidos.innerHTML='Apellidos';
  headerEdad.innerHTML='Edad';

  for (var i=0;i<data_source.length;i++){
    var row=document.createElement('tr');
    tbl.appendChild(row);
    var nameTd=document.createElement('td');
    var surnameTd=document.createElement('td');
    var ageTd=document.createElement('td');

    row.appendChild(nameTd);
    row.appendChild(surnameTd);
    row.appendChild(ageTd);

    nameTd.innerHTML=data_source[i].nombre;
    surnameTd.innerHTML=data_source[i].apellidos;
    ageTd.innerHTML=data_source[i].edad;

  }

}

create_table();

const http=new XMLHttpRequest();
http.open("GET",'https://jsonplaceholder.typicode.com/photos');,
http.send();
http.onreadystatechange=(e)=>{
  if(request.readyState===4)
  {
      var data=(JSON.parse(request.responseText));
      console.log(data);
      for(var=i=0;i<25;i++)
      {
        var p=data[i];
        var photo=new Photo(p.ide,pd.albumID)
      }
  }

}
