/* Primera manera de escribir, creando un texto a la salida Pop Up*/
alert("Viva la Roja! Desde un fichero externo!");

/* Segunda manera de escribir, 
creando un texto a la salida de la consola*/
console.log("Viva Espania! Desde un fichero externo!");

/*Tercera manera de escribir,
creando un texto en el propio HTML.*/
document.write("Viva la Republica! En el HTML!");