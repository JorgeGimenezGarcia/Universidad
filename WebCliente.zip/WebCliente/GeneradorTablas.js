document.getElementById('Boton').onclick=function(){

  var celda= document.getElementById("id_celda").value
  document.getElementById(celda).innerHTML=document.getElementById("id_texto").value
}
