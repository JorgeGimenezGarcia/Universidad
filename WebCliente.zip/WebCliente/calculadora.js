
function calculaArea(altura,anchura)
{
	var area= altura * anchura;
	return area;
}

document.getElementById("idCalc1").onclick = function(){
	alert(
		calculaArea(document.getElementById("idAltura").value,document.getElementById("idAnchura").value)
		);
}