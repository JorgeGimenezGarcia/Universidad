function valida_formulario(){
	// VALIDANDO QUE EL FORMULARIO NO ES VACIO:
	if(document.mi_formulario.nombre.value ==""){
		alert("Rellenar su nombre!");
		document.mi_formulario.nombre.focus();
		return(false);
	}
	// VALIDANDO EL EMAIL
	var valor_email = document.mi_formulario.email.value;
	posicion_del_arroba = valor_email.indexOf("@");
	posicion_del_ultimo_punto = valor_email.lastIndexOf(".");
	
	if((posicion_del_arroba < 0) || 
	(posicion_del_ultimo_punto - posicion_del_arroba) < 2){
		alert("Email no es valido!");
		document.mi_formulario.email.focus();
		return(false);
	}
	
	//Validar el telefono
	if (document.mi_formulario.telefono.value.length != 9){
		alert("Telefóno no es válido!");
		document.mi_formulario.telefono.focus();
		return(false);			 
	}
	
	return(true);
}