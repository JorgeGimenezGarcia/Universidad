function valida_formulario(){
	// VALIDANDO QUE EL FORMULARIO NO ES VACIO:
	if(document.mi_formulario.nombre.value ==""){
		alert("Rellenar su nombre!");
		document.mi_formulario.nombre.focus();
		return(false);
	}
	// VALIDANDO EL EMAIL
	var valor_email = document.mi_formulario.email.value;
	posicion_del_arroba = valor_email.indexOf("@");
	posicion_del_ultimo_punto = valor_email.lastIndexOf(".");

	if((posicion_del_arroba < 0) ||
	(posicion_del_ultimo_punto - posicion_del_arroba) < 2){
		alert("Email no es valido!");
		document.mi_formulario.email.focus();
		return(false);
	}

  var tlf=/^\d{10}$/;
  if(document.mi_formulario.telefono.value)
  {
    return true;
  }
  else {
    alert("No es valido");
    retunr false;
  }

	return(true);
}
